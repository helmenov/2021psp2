from .day06package.mymodule1 import *
