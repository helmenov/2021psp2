# mymodule1.py

MESSAGE = 'hello world'

def hello():
    print(MESSAGE)

